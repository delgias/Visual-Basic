﻿Public Class Form1

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim pounds As Integer
        Dim height As Integer

        pounds = CInt(TextBox1.Text)
        height = CInt(TextBox2.Text)

        TextBox3.Text = (pounds * 703) / (height * height)
        RichTextBox1.Text = ("BMI VALUES" & Environment.NewLine & "Underweight:  less than 18.5" & Environment.NewLine & "Normal:       between 18.5 and 24.9" & Environment.NewLine & "Overweight:   between 25 and 29.9" & Environment.NewLine & "Obese:        30 or greater")
    End Sub

    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged




    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
